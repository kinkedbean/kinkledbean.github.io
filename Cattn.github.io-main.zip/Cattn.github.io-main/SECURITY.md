# Security Policy

## Reporting a Vulnerability

If you find a vulnerability with something in my website, or linked code or embeds please notify me on my discord that is included in the readme

Ty 
- Logan
